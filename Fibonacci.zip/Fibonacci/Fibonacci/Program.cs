﻿    using System;

namespace Fibonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] fibo = new int[32];

            Console.WriteLine("Bitte geben Sie Zahl 0 der F-Folge ein: ");
            fibo[0] = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Bitte geben Sie Zahl 1 der F-Folge ein: ");
            fibo[1] = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            
            for (int n = 2; n < 32; n++)

            {
                fibo[n] = fibo[n - 1] + fibo[n - 2];

            }

            for (int m = 0; m < fibo.Length; m++)
            {
                Console.WriteLine("Index" + m + "  " + fibo[m]);
            }
        }
    }
}
